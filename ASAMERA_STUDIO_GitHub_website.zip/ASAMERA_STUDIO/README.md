# ASAMERA STUDIO

Responsive static website prototype for the ASAMERA STUDIO voice-generation project.

## Files
- `index.html` — website and browser speech preview.

## Current limits
- This prototype does not clone your personal voice.
- Preview uses voices available in the device/browser; Amharic availability varies.
- It does not yet create or download MP3 files.
- Real voice cloning requires a compatible AI provider and a secure backend.
- Never publish a private API key in this repository.

## Publish with GitHub Pages
1. Open your repository on GitHub.
2. Tap **Add file → Upload files**.
3. Upload `index.html` and `README.md` from this folder.
4. Commit changes to the `main` branch.
5. Open **Settings → Pages**.
6. Under Build and deployment, select **Deploy from a branch**.
7. Select branch `main` and folder `/ (root)`, then tap **Save**.
8. Wait a few minutes. Return to Settings → Pages to see the site address.

If `index.html` already exists, replace it with this new one.
